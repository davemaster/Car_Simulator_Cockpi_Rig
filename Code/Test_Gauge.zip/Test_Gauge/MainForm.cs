﻿/*
 * Created by SharpDevelop.
 * User: davem
 * Date: 13/09/2024
 * Time: 18:01
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
using AquaControls;

namespace Test_Gauge
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		bool bLights_on=false;
		bool bWasher_on=false;
		bool bPanel_on=false;
		bool bWiper_on=false;
		
		String WorkingDirectory=String.Empty;
		
		System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			System.Drawing.Rectangle workingArea= System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
			
			//this.Width=workingArea.Width;
			//pictureBoxDashBoard.Width=workingArea.Width;
			aquaGaugeRPM.DialText="RPM x 1000";
			aquaGaugeRPM.MaxValue=9;
			aquaGaugeRPM.Value=2;	
			aquaGaugeRPM.RecommendedValue=7;
						
			//aquaGaugeSPEED.DialText="Speed MPH";
			aquaGaugeSPEED.MaxValue=160;
			aquaGaugeSPEED.Value=0;
			aquaGaugeSPEED.RecommendedValue=120;
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		
		#region Form_funtions
				
		void MainFormLoad(object sender, EventArgs e)
		{
			WorkingDirectory=System.IO.Directory.GetCurrentDirectory();		
			
			buttonPanel.Image=(Image)(resources.GetObject("gray_btn_off"));
			buttonLights.Image=(Image)(resources.GetObject("gray_btn_off"));
			buttonWasher.Image=(Image)(resources.GetObject("blue_btn_off"));
			buttonWiper.Image=(Image)(resources.GetObject("blue_btn_off"));
	
		}
		
		#endregion Form_functions
		
		#region Gauges
		
		
		void AquaGaugeFuelLoad(object sender, EventArgs e)
		{
	
		}
		void AquaGaugeTempLoad(object sender, EventArgs e)
		{
	
		}
		void AquaGaugePressureLoad(object sender, EventArgs e)
		{
	
		}
		void AquaGaugeVoltLoad(object sender, EventArgs e)
		{
	
		}
		
		#endregion Gauges
		
		#region Switches
		
		void setLights_BtnImage(object sender, EventArgs e)
		{
			Button btnTemp=(Button)sender;
			
			if(!bLights_on)
			{				
				bLights_on=true;								
				btnTemp.Image=(Image)(resources.GetObject("gray_btn_on"));				
				
			}
			else if(bLights_on)
			{
				bLights_on=false;
				btnTemp.Image=(Image)(resources.GetObject("gray_btn_off"));			
			}		
		}
		
		void setPanel_BtnImage(object sender, EventArgs e)
		{
			Button btnTemp=(Button)sender;
			
			if(!bPanel_on)
			{				
				bPanel_on=true;				
				btnTemp.Image=(Image)(resources.GetObject("gray_btn_on"));	
				
			}
			else if(bPanel_on)
			{
				bPanel_on=false;
				btnTemp.Image=(Image)(resources.GetObject("gray_btn_off"));	
			}		
		}
		
		void setWasher_BtnImage(object sender, EventArgs e)
		{
			Button btnTemp=(Button)sender;
			
			if(!bWasher_on)
			{				
				bWasher_on=true;				
				btnTemp.Image=(Image)(resources.GetObject("blue_btn_on"));	
				
			}
			else if(bWasher_on)
			{
				bWasher_on=false;
				btnTemp.Image=(Image)(resources.GetObject("blue_btn_off"));			
			}		
		}
		
		void setWiper_BtnImage(object sender, EventArgs e)
		{
			Button btnTemp=(Button)sender;
			
			if(!bWiper_on)
			{				
				bWiper_on=true;				
				btnTemp.Image=(Image)(resources.GetObject("blue_btn_on"));	
				
			}
			else if(bWiper_on)
			{
				bWiper_on=false;
				btnTemp.Image=(Image)(resources.GetObject("blue_btn_off"));		
			}		
		}
		
		
		void ButtonLightsClick(object sender, EventArgs e)
		{		
			setLights_BtnImage(sender,e);
		}
		
		void ButtonPanelClick(object sender, EventArgs e)
		{
			setPanel_BtnImage(sender,e);
		}
		
		void ButtonWiperClick(object sender, EventArgs e)
		{
			setWiper_BtnImage(sender,e);
		}
		
		void ButtonWasherClick(object sender, EventArgs e)
		{
			setWasher_BtnImage(sender,e);
		}
		
		#endregion Switches
		
		
		#region Trackbars
		
		
		void TrackBarSpeedValueChanged(object sender, EventArgs e)
		{
			aquaGaugeSPEED.Value = trackBarSpeed.Value;
		}

		void TrackBarRPMValueChanged(object sender, EventArgs e)
		{
			aquaGaugeRPM.Value = trackBarRPM.Value;
		}
		
		void TrackBarBrakeValueChanged(object sender, EventArgs e)
		{
			
			var bmp = (Bitmap)(resources.GetObject("led_brake_on"));				
			pictureBoxBrakeLed.BackgroundImage = brightnes(bmp , trackBarBrake.Value);

		}
		
		
		Bitmap brightnes(Bitmap OriginalImage, int Value)
        {
            int brightness = Value;
            var temp = OriginalImage;
            Bitmap bmap = (Bitmap)temp.Clone();
            if (brightness < -255) brightness = -255;
            if (brightness > 255) brightness = 255;
            Color c;
            for(int i=0;i<bmap.Width;i++)
            {
                for (int j = 0; j < bmap.Height; j++)
                {
                    c = bmap.GetPixel(i, j);
                    int cR = c.R + brightness;
                    //int cG = c.G + brightness;
                    int cG=c.G;
                    //int cB = c.B + brightness;
                    int cB = c.B;
                    if (cR < 0) cR = 1;
                    if (cR > 255) cR = 255;
                    //if (cG < 0) cG = 1;
                    //if (cG > 255) cG = 255;
                    //if (cB < 0) cB = 1;
                    //if (cB > 255) cB = 255;
                    bmap.SetPixel(i, j, Color.FromArgb((byte)cR, (byte)cG, (byte)cB));
                }
            }
            
            return bmap;
        }
		
		public static Bitmap AdjustBrightness(Bitmap OriginalImage, int Value)
		{
			Bitmap TempBitmap = OriginalImage;
			
			float FinalValue = (float)Value/255.0f;
			
			Bitmap NewBitmap = new Bitmap (TempBitmap.Width, TempBitmap.Height);
			
			Graphics NewGraphics = Graphics.FromImage(NewBitmap);
			
			float [][] FloatColorMatrix = {
							new float[] {1,0,0,0,0},
							new float[] {0,1,0,0,0},
							new float[] {0,0,1,0,0},
							new float[] {0,0,0,1,0},
							new float[] {FinalValue,FinalValue,FinalValue,1,1}					
						};
						
			ColorMatrix NewColorMatrix = new ColorMatrix(FloatColorMatrix);
			ImageAttributes Attributes = new ImageAttributes();
			
			Attributes.SetColorMatrix(NewColorMatrix);
			NewGraphics.DrawImage(TempBitmap, 
									new Rectangle(0,0, TempBitmap.Width, TempBitmap.Height),
									0,0,
									TempBitmap.Width,
									TempBitmap.Height,
									GraphicsUnit.Pixel,
									Attributes);
			
			Attributes.Dispose();
			NewGraphics.Dispose();	

			return NewBitmap;				
		}
		#endregion Trackbars
		
	}
}
