﻿/*
 * Created by SharpDevelop.
 * User: davem
 * Date: 13/09/2024
 * Time: 18:01
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Test_Gauge
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private AquaControls.AquaGauge aquaGaugeSPEED;
		private System.Windows.Forms.PictureBox pictureBoxDashBoard;
		private AquaControls.AquaGauge aquaGaugeRPM;
		private System.Windows.Forms.Button buttonLights;
		private AquaControls.AquaGauge aquaGaugeFuel;
		private AquaControls.AquaGauge aquaGaugeTemp;
		private AquaControls.AquaGauge aquaGaugePressure;
		private AquaControls.AquaGauge aquaGaugeVolt;
		private System.Windows.Forms.Button buttonPanel;
		private System.Windows.Forms.Button buttonWiper;
		private System.Windows.Forms.Button buttonWasher;
		private System.Windows.Forms.TrackBar trackBarSpeed;
		private System.Windows.Forms.TrackBar trackBarRPM;
		private System.Windows.Forms.TrackBar trackBarBrake;
		private System.Windows.Forms.Label labelTrackBarSpeed;
		private System.Windows.Forms.Label labelBrake;
		private System.Windows.Forms.Label labelRPM;
		private System.Windows.Forms.PictureBox pictureBoxBrakeLed;
		
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.pictureBoxDashBoard = new System.Windows.Forms.PictureBox();
			this.aquaGaugeSPEED = new AquaControls.AquaGauge();
			this.aquaGaugeRPM = new AquaControls.AquaGauge();
			this.buttonLights = new System.Windows.Forms.Button();
			this.aquaGaugeFuel = new AquaControls.AquaGauge();
			this.aquaGaugeTemp = new AquaControls.AquaGauge();
			this.aquaGaugePressure = new AquaControls.AquaGauge();
			this.aquaGaugeVolt = new AquaControls.AquaGauge();
			this.buttonPanel = new System.Windows.Forms.Button();
			this.buttonWiper = new System.Windows.Forms.Button();
			this.buttonWasher = new System.Windows.Forms.Button();
			this.trackBarSpeed = new System.Windows.Forms.TrackBar();
			this.trackBarRPM = new System.Windows.Forms.TrackBar();
			this.trackBarBrake = new System.Windows.Forms.TrackBar();
			this.labelTrackBarSpeed = new System.Windows.Forms.Label();
			this.labelBrake = new System.Windows.Forms.Label();
			this.labelRPM = new System.Windows.Forms.Label();
			this.pictureBoxBrakeLed = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxDashBoard)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBarSpeed)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBarRPM)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBarBrake)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxBrakeLed)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBoxDashBoard
			// 
			this.pictureBoxDashBoard.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxDashBoard.BackgroundImage")));
			this.pictureBoxDashBoard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBoxDashBoard.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pictureBoxDashBoard.Location = new System.Drawing.Point(0, 2);
			this.pictureBoxDashBoard.MinimumSize = new System.Drawing.Size(300, 300);
			this.pictureBoxDashBoard.Name = "pictureBoxDashBoard";
			this.pictureBoxDashBoard.Size = new System.Drawing.Size(1840, 520);
			this.pictureBoxDashBoard.TabIndex = 5;
			this.pictureBoxDashBoard.TabStop = false;
			// 
			// aquaGaugeSPEED
			// 
			this.aquaGaugeSPEED.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.aquaGaugeSPEED.DialColor = System.Drawing.Color.Gray;
			this.aquaGaugeSPEED.DialText = "000000";
			this.aquaGaugeSPEED.ForeColor = System.Drawing.Color.White;
			this.aquaGaugeSPEED.Glossiness = 11.36364F;
			this.aquaGaugeSPEED.Location = new System.Drawing.Point(328, 46);
			this.aquaGaugeSPEED.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.aquaGaugeSPEED.MaximumSize = new System.Drawing.Size(500, 500);
			this.aquaGaugeSPEED.MaxValue = 0F;
			this.aquaGaugeSPEED.MinimumSize = new System.Drawing.Size(200, 200);
			this.aquaGaugeSPEED.MinValue = 0F;
			this.aquaGaugeSPEED.Name = "aquaGaugeSPEED";
			this.aquaGaugeSPEED.RecommendedValue = 0F;
			this.aquaGaugeSPEED.Size = new System.Drawing.Size(435, 435);
			this.aquaGaugeSPEED.TabIndex = 1;
			this.aquaGaugeSPEED.ThresholdPercent = 0F;
			this.aquaGaugeSPEED.Value = 0F;
			// 
			// aquaGaugeRPM
			// 
			this.aquaGaugeRPM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.aquaGaugeRPM.DialColor = System.Drawing.Color.Gray;
			this.aquaGaugeRPM.DialText = null;
			this.aquaGaugeRPM.ForeColor = System.Drawing.Color.White;
			this.aquaGaugeRPM.Glossiness = 11.36364F;
			this.aquaGaugeRPM.Location = new System.Drawing.Point(759, 43);
			this.aquaGaugeRPM.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.aquaGaugeRPM.MaximumSize = new System.Drawing.Size(500, 500);
			this.aquaGaugeRPM.MaxValue = 0F;
			this.aquaGaugeRPM.MinimumSize = new System.Drawing.Size(200, 200);
			this.aquaGaugeRPM.MinValue = 0F;
			this.aquaGaugeRPM.Name = "aquaGaugeRPM";
			this.aquaGaugeRPM.RecommendedValue = 0F;
			this.aquaGaugeRPM.Size = new System.Drawing.Size(435, 435);
			this.aquaGaugeRPM.TabIndex = 6;
			this.aquaGaugeRPM.ThresholdPercent = 0F;
			this.aquaGaugeRPM.Value = 0F;
			// 
			// buttonLights
			// 
			this.buttonLights.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonLights.BackgroundImage")));
			this.buttonLights.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.buttonLights.Location = new System.Drawing.Point(26, 46);
			this.buttonLights.Margin = new System.Windows.Forms.Padding(0);
			this.buttonLights.Name = "buttonLights";
			this.buttonLights.Size = new System.Drawing.Size(122, 211);
			this.buttonLights.TabIndex = 7;
			this.buttonLights.UseVisualStyleBackColor = true;
			this.buttonLights.Click += new System.EventHandler(this.ButtonLightsClick);
			// 
			// aquaGaugeFuel
			// 
			this.aquaGaugeFuel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.aquaGaugeFuel.DialColor = System.Drawing.Color.Lavender;
			this.aquaGaugeFuel.DialText = null;
			this.aquaGaugeFuel.ForeColor = System.Drawing.Color.White;
			this.aquaGaugeFuel.Glossiness = 11.36364F;
			this.aquaGaugeFuel.Location = new System.Drawing.Point(1176, 35);
			this.aquaGaugeFuel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.aquaGaugeFuel.MaxValue = 0F;
			this.aquaGaugeFuel.MinValue = 0F;
			this.aquaGaugeFuel.Name = "aquaGaugeFuel";
			this.aquaGaugeFuel.RecommendedValue = 0F;
			this.aquaGaugeFuel.Size = new System.Drawing.Size(138, 138);
			this.aquaGaugeFuel.TabIndex = 8;
			this.aquaGaugeFuel.ThresholdPercent = 0F;
			this.aquaGaugeFuel.Value = 0F;
			this.aquaGaugeFuel.Load += new System.EventHandler(this.AquaGaugeFuelLoad);
			// 
			// aquaGaugeTemp
			// 
			this.aquaGaugeTemp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.aquaGaugeTemp.DialColor = System.Drawing.Color.Lavender;
			this.aquaGaugeTemp.DialText = null;
			this.aquaGaugeTemp.ForeColor = System.Drawing.Color.White;
			this.aquaGaugeTemp.Glossiness = 11.36364F;
			this.aquaGaugeTemp.Location = new System.Drawing.Point(1367, 35);
			this.aquaGaugeTemp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.aquaGaugeTemp.MaxValue = 0F;
			this.aquaGaugeTemp.MinValue = 0F;
			this.aquaGaugeTemp.Name = "aquaGaugeTemp";
			this.aquaGaugeTemp.RecommendedValue = 0F;
			this.aquaGaugeTemp.Size = new System.Drawing.Size(138, 138);
			this.aquaGaugeTemp.TabIndex = 9;
			this.aquaGaugeTemp.ThresholdPercent = 0F;
			this.aquaGaugeTemp.Value = 0F;
			this.aquaGaugeTemp.Load += new System.EventHandler(this.AquaGaugeTempLoad);
			// 
			// aquaGaugePressure
			// 
			this.aquaGaugePressure.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.aquaGaugePressure.DialColor = System.Drawing.Color.Lavender;
			this.aquaGaugePressure.DialText = null;
			this.aquaGaugePressure.ForeColor = System.Drawing.Color.White;
			this.aquaGaugePressure.Glossiness = 11.36364F;
			this.aquaGaugePressure.Location = new System.Drawing.Point(1552, 35);
			this.aquaGaugePressure.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.aquaGaugePressure.MaxValue = 0F;
			this.aquaGaugePressure.MinValue = 0F;
			this.aquaGaugePressure.Name = "aquaGaugePressure";
			this.aquaGaugePressure.RecommendedValue = 0F;
			this.aquaGaugePressure.Size = new System.Drawing.Size(138, 138);
			this.aquaGaugePressure.TabIndex = 10;
			this.aquaGaugePressure.ThresholdPercent = 0F;
			this.aquaGaugePressure.Value = 0F;
			this.aquaGaugePressure.Load += new System.EventHandler(this.AquaGaugePressureLoad);
			// 
			// aquaGaugeVolt
			// 
			this.aquaGaugeVolt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.aquaGaugeVolt.DialColor = System.Drawing.Color.Lavender;
			this.aquaGaugeVolt.DialText = null;
			this.aquaGaugeVolt.ForeColor = System.Drawing.Color.White;
			this.aquaGaugeVolt.Glossiness = 11.36364F;
			this.aquaGaugeVolt.Location = new System.Drawing.Point(1176, 230);
			this.aquaGaugeVolt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.aquaGaugeVolt.MaxValue = 0F;
			this.aquaGaugeVolt.MinValue = 0F;
			this.aquaGaugeVolt.Name = "aquaGaugeVolt";
			this.aquaGaugeVolt.RecommendedValue = 0F;
			this.aquaGaugeVolt.Size = new System.Drawing.Size(138, 138);
			this.aquaGaugeVolt.TabIndex = 11;
			this.aquaGaugeVolt.ThresholdPercent = 0F;
			this.aquaGaugeVolt.Value = 0F;
			this.aquaGaugeVolt.Load += new System.EventHandler(this.AquaGaugeVoltLoad);
			// 
			// buttonPanel
			// 
			this.buttonPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonPanel.BackgroundImage")));
			this.buttonPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.buttonPanel.Location = new System.Drawing.Point(154, 46);
			this.buttonPanel.Margin = new System.Windows.Forms.Padding(0);
			this.buttonPanel.Name = "buttonPanel";
			this.buttonPanel.Size = new System.Drawing.Size(122, 211);
			this.buttonPanel.TabIndex = 12;
			this.buttonPanel.UseVisualStyleBackColor = true;
			this.buttonPanel.Click += new System.EventHandler(this.ButtonPanelClick);
			// 
			// buttonWiper
			// 
			this.buttonWiper.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonWiper.BackgroundImage")));
			this.buttonWiper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.buttonWiper.Location = new System.Drawing.Point(1488, 281);
			this.buttonWiper.Margin = new System.Windows.Forms.Padding(0);
			this.buttonWiper.Name = "buttonWiper";
			this.buttonWiper.Size = new System.Drawing.Size(122, 211);
			this.buttonWiper.TabIndex = 13;
			this.buttonWiper.UseVisualStyleBackColor = true;
			this.buttonWiper.Click += new System.EventHandler(this.ButtonWiperClick);
			// 
			// buttonWasher
			// 
			this.buttonWasher.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonWasher.BackgroundImage")));
			this.buttonWasher.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.buttonWasher.Location = new System.Drawing.Point(1617, 281);
			this.buttonWasher.Margin = new System.Windows.Forms.Padding(0);
			this.buttonWasher.Name = "buttonWasher";
			this.buttonWasher.Size = new System.Drawing.Size(122, 211);
			this.buttonWasher.TabIndex = 14;
			this.buttonWasher.UseVisualStyleBackColor = true;
			this.buttonWasher.Click += new System.EventHandler(this.ButtonWasherClick);
			// 
			// trackBarSpeed
			// 
			this.trackBarSpeed.Location = new System.Drawing.Point(423, 558);
			this.trackBarSpeed.Maximum = 160;
			this.trackBarSpeed.Name = "trackBarSpeed";
			this.trackBarSpeed.Size = new System.Drawing.Size(258, 69);
			this.trackBarSpeed.TabIndex = 15;
			this.trackBarSpeed.ValueChanged += new System.EventHandler(this.TrackBarSpeedValueChanged);
			// 
			// trackBarRPM
			// 
			this.trackBarRPM.Location = new System.Drawing.Point(849, 558);
			this.trackBarRPM.Maximum = 9;
			this.trackBarRPM.Minimum = 1;
			this.trackBarRPM.Name = "trackBarRPM";
			this.trackBarRPM.Size = new System.Drawing.Size(258, 69);
			this.trackBarRPM.TabIndex = 16;
			this.trackBarRPM.Value = 1;
			this.trackBarRPM.ValueChanged += new System.EventHandler(this.TrackBarRPMValueChanged);
			// 
			// trackBarBrake
			// 
			this.trackBarBrake.Location = new System.Drawing.Point(26, 558);
			this.trackBarBrake.Maximum = 80;
			this.trackBarBrake.Minimum = 1;
			this.trackBarBrake.Name = "trackBarBrake";
			this.trackBarBrake.Size = new System.Drawing.Size(250, 69);
			this.trackBarBrake.TabIndex = 17;
			this.trackBarBrake.Value = 1;
			this.trackBarBrake.ValueChanged += new System.EventHandler(this.TrackBarBrakeValueChanged);
			// 
			// labelTrackBarSpeed
			// 
			this.labelTrackBarSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelTrackBarSpeed.Location = new System.Drawing.Point(423, 617);
			this.labelTrackBarSpeed.Name = "labelTrackBarSpeed";
			this.labelTrackBarSpeed.Size = new System.Drawing.Size(258, 69);
			this.labelTrackBarSpeed.TabIndex = 18;
			this.labelTrackBarSpeed.Text = "Speed";
			this.labelTrackBarSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelBrake
			// 
			this.labelBrake.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelBrake.Location = new System.Drawing.Point(26, 617);
			this.labelBrake.Name = "labelBrake";
			this.labelBrake.Size = new System.Drawing.Size(258, 69);
			this.labelBrake.TabIndex = 19;
			this.labelBrake.Text = "Brake";
			this.labelBrake.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelRPM
			// 
			this.labelRPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.labelRPM.Location = new System.Drawing.Point(849, 617);
			this.labelRPM.Name = "labelRPM";
			this.labelRPM.Size = new System.Drawing.Size(258, 69);
			this.labelRPM.TabIndex = 20;
			this.labelRPM.Text = "RPM";
			this.labelRPM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBoxBrakeLed
			// 
			this.pictureBoxBrakeLed.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxBrakeLed.BackgroundImage")));
			this.pictureBoxBrakeLed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBoxBrakeLed.Location = new System.Drawing.Point(26, 262);
			this.pictureBoxBrakeLed.Name = "pictureBoxBrakeLed";
			this.pictureBoxBrakeLed.Size = new System.Drawing.Size(122, 216);
			this.pictureBoxBrakeLed.TabIndex = 21;
			this.pictureBoxBrakeLed.TabStop = false;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.ClientSize = new System.Drawing.Size(1837, 804);
			this.Controls.Add(this.pictureBoxBrakeLed);
			this.Controls.Add(this.labelRPM);
			this.Controls.Add(this.labelBrake);
			this.Controls.Add(this.labelTrackBarSpeed);
			this.Controls.Add(this.trackBarBrake);
			this.Controls.Add(this.trackBarRPM);
			this.Controls.Add(this.trackBarSpeed);
			this.Controls.Add(this.buttonWasher);
			this.Controls.Add(this.buttonWiper);
			this.Controls.Add(this.buttonPanel);
			this.Controls.Add(this.aquaGaugeVolt);
			this.Controls.Add(this.aquaGaugePressure);
			this.Controls.Add(this.aquaGaugeTemp);
			this.Controls.Add(this.aquaGaugeFuel);
			this.Controls.Add(this.buttonLights);
			this.Controls.Add(this.aquaGaugeRPM);
			this.Controls.Add(this.aquaGaugeSPEED);
			this.Controls.Add(this.pictureBoxDashBoard);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "MainForm";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "DaveWare® Design - Dodge Charger 1969";
			this.Load += new System.EventHandler(this.MainFormLoad);
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxDashBoard)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBarSpeed)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBarRPM)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBarBrake)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxBrakeLed)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
		
	}
}
